package wak.work.cryptogram.graem.securecrypto;

/**
 * Created with IntelliJ IDEA.
 * User: graeme.rowles
 * Date: 11/02/13
 * Time: 14:37
 */
public interface ISCIExceptionResponse
{
    public Throwable getSciException();
}
