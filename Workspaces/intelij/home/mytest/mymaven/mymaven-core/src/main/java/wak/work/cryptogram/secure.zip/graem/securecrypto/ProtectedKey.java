
package wak.work.cryptogram.graem.securecrypto;

public interface ProtectedKey extends Key
{
}
