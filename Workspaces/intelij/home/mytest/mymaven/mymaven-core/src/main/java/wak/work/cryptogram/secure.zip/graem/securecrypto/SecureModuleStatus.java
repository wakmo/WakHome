/*
 * SecureModuleStatus.java
 *
 * Created on 17 October 2001, 13:42
 */

package wak.work.cryptogram.graem.securecrypto;

import java.io.Serializable;
//import com.platform7.hsm.HsmStatusResponse;

/**
 *
 * @author  Richard Izzard
 * @version
 */
public interface SecureModuleStatus extends Serializable{

}
