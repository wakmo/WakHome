package wak.work.cryptogram.graem.securecrypto;

public enum RsaKeyType {
	CRT,
	MODULUS_EXPONENT
}
